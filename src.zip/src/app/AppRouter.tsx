import { createBrowserRouter, Navigate } from 'react-router-dom';
import { AppLayout } from './layout/AppLayout';
import { ROUTES } from './navigation/routes';
import { AuthorizationBoundary } from '../common/auth/AuthorizationBoundary';

import { PublicCatalogPage } from '../features/catalog/public/pages/PublicCatalogPage';
import { PublicProductDetailsPage } from '../features/catalog/public/pages/PublicProductDetailsPage';
import { 
  AdminCatalogListPage, 
  AdminProductDetailsPage, 
  AdminCreateProductPage, 
  AdminEditProductPage 
} from '../features/catalog';

const Orders = () => <h1 className="p-8 font-bold text-2xl text-text-primary">Action Zone (Protected)</h1>;
const NotFound = () => <h1 className="p-8 font-bold text-2xl text-text-primary">404 - Not Found</h1>;

export const AppRouter = createBrowserRouter([
  {
    path: ROUTES.HOME,
    element: <AppLayout />, 
    children: [
      // Temporary root redirect to Admin for Ravi's V1 Workflow
      { index: true, element: <Navigate to={ROUTES.ADMIN_CATALOG} replace /> },
      
      // Reserved Public Routes (Discovery Zone)
      { path: 'catalog', element: <PublicCatalogPage /> },
      { path: 'catalog/:slug', element: <PublicProductDetailsPage /> },
      
      // Protected Operational Routes (Action & Admin Zones)
      {
        element: <AuthorizationBoundary />,
        children: [
          { path: ROUTES.ORDERS, element: <Orders /> },
          { 
            path: 'admin/catalog', 
            children: [
              { index: true, element: <AdminCatalogListPage /> },
              { path: 'new', element: <AdminCreateProductPage /> },
              { path: ':slug', element: <AdminProductDetailsPage /> },
              { path: ':slug/edit', element: <AdminEditProductPage /> },
            ]
          },
        ]
      },
      { path: '*', element: <NotFound /> }
    ],
  },
]);