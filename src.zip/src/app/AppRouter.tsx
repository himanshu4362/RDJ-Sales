import { createBrowserRouter, Navigate } from 'react-router-dom';
import { AppLayout } from './layout/AppLayout';
import { ROUTES } from './navigation/routes';
import { AuthorizationBoundary } from '../common/auth/AuthorizationBoundary';

// Feature Pages
import { CatalogListPage } from '../features/catalog/pages/CatalogListPage';
import { ProductDetailsPage } from '../features/catalog/pages/ProductDetailsPage';
import { CreateProductPage } from '../features/catalog/pages/CreateProductPage';
import { EditProductPage } from '../features/catalog/pages/EditProductPage';

const Orders = () => <h1 className="p-8 font-bold text-2xl text-text-primary">Action Zone (Protected)</h1>;
const NotFound = () => <h1 className="p-8 font-bold text-2xl text-text-primary">404 - Not Found</h1>;

export const AppRouter = createBrowserRouter([
  {
    path: ROUTES.HOME,
    element: <AppLayout />, 
    children: [
      // Temporary V1 Route: Dump root directly to Catalog until Dashboard is built
      { index: true, element: <Navigate to={ROUTES.CATALOG} replace /> },
      
      // Catalog Workflow Vertical
      { 
        path: ROUTES.CATALOG, 
        element: <CatalogListPage /> 
      },
      { 
        path: ROUTES.PRODUCT_CREATE, 
        element: <CreateProductPage /> 
      },
      { 
        // Uses parameter tokens for matching, matching the structure of your generator functions
        path: '/catalog/:slug', 
        element: <ProductDetailsPage /> 
      },
      { 
        path: '/catalog/:slug/edit', 
        element: <EditProductPage /> 
      },
      
      {
        element: <AuthorizationBoundary />,
        children: [
          { path: ROUTES.ORDERS, element: <Orders /> },
        ]
      },
      
      { path: '*', element: <NotFound /> }
    ],
  },
]);
