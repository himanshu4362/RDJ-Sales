import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ROUTES } from '../../../../app/navigation/routes';
import { usePublicCatalogList } from '../hooks/public.hooks';
import { LoadingSkeleton } from '../../../../common/components/ui/LoadingSkeleton';

export const PublicCatalogPage: React.FC = () => {
  const navigate = useNavigate();
  const { data, isLoading } = usePublicCatalogList({}); // No filters for MVP public

  if (isLoading) return <LoadingSkeleton className="h-64 w-full" />;

  return (
    <div className="flex flex-col gap-8 max-w-5xl mx-auto w-full">
      <h1 className="text-3xl font-bold text-text-primary text-center">RDJ Professional Audio</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {data?.data.map((product) => (
          <div 
            key={product.id} 
            onClick={() => navigate(ROUTES.PRODUCT_DETAILS(product.slug))}
            className="cursor-pointer group flex flex-col gap-3 bg-surface-primary border border-border-default rounded-lg p-4 transition-all hover:shadow-md hover:border-brand-primary"
          >
            <div className="aspect-square bg-surface-secondary rounded-md overflow-hidden">
              {product.images[0] && <img src={product.images[0].url} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />}
            </div>
            <div>
              <p className="text-xs font-semibold text-text-muted uppercase">{product.brandName}</p>
              <h3 className="text-sm font-bold text-text-primary line-clamp-2">{product.name}</h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};