import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { ROUTES } from '../../../../app/navigation/routes';
import { usePublicProductDetails } from '../hooks/public.hooks';
import { LoadingSkeleton } from '../../../../common/components/ui/LoadingSkeleton';

export const PublicProductDetailsPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { data: product, isLoading } = usePublicProductDetails(slug ?? '');

  if (isLoading || !product) return <LoadingSkeleton className="h-96 w-full" />;
  
  // Public safety check: Even if somehow fetched, do not display inactive products publicly
  if (product.status !== 'ACTIVE') {
    return <div className="p-8 text-center text-text-muted">Product unavailable.</div>;
  }

  return (
    <div className="flex flex-col gap-8 max-w-4xl mx-auto w-full">
      <button onClick={() => navigate(ROUTES.CATALOG)} className="flex items-center gap-2 text-text-secondary hover:text-text-primary w-max">
        <ArrowLeft size={20} /> Back to Catalog
      </button>
      
      <div className="flex flex-col md:flex-row gap-8">
        <div className="w-full md:w-1/2 aspect-square bg-surface-secondary rounded-lg overflow-hidden border border-border-default">
           {product.images[0] && <img src={product.images[0].url} alt={product.name} className="w-full h-full object-cover" />}
        </div>
        <div className="w-full md:w-1/2 flex flex-col gap-4">
          <div>
            <span className="text-xs font-bold text-text-muted uppercase tracking-wider">{product.brandName} • {product.modelNumber}</span>
            <h1 className="text-3xl font-bold text-text-primary leading-tight mt-1">{product.name}</h1>
          </div>
          <p className="text-text-secondary">{product.description || product.shortDescription}</p>
          
          <div className="mt-4 pt-6 border-t border-border-default">
            <h2 className="text-lg font-bold text-text-primary mb-4">Technical Specifications</h2>
            <dl className="divide-y divide-border-default">
              {product.specifications.map((spec, index) => (
                <div key={index} className="flex justify-between py-2">
                  <dt className="text-sm text-text-secondary">{spec.name}</dt>
                  <dd className="text-sm font-bold text-text-primary">{spec.value}</dd>
                </div>
              ))}
            </dl>
          </div>
          
          <div className="mt-8">
            {/* Commercial Intent Placeholder */}
            <button className="w-full bg-brand-primary text-surface-primary font-bold h-14 rounded-md hover:bg-brand-secondary transition-colors">
              Inquire About Product
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};