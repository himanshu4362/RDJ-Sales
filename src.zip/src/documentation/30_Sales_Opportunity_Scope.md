---
Status: Frozen (V1)
Owner: Himanshu Raj
Purpose: To define the business rules, data requirements, and customer journey for the Sales Opportunity vertical.
---

# 30_Sales_Opportunity_Scope.md

## 1. Vertical Name
Sales Opportunity Management (Customer Opportunity Pipeline)

## 2. Business Problem
High-intent customers currently discover products but have no structured way to request a quote or check availability. Leads get lost in WhatsApp, and Ravi's team wastes time gathering basic context (which product, where is the customer located) before they can begin selling.

## 3. Desired Digital Workflow
Customer views product → Triggers Request → Fills minimal context form → Request drops into Rana Sales Workspace → Admin views structured request and updates pipeline status.

## 4. The Customer Journey
`Browsing Products` → `Interested` → `Starts Request` → `Provides Minimal Info` → `Confirmation/Success State` → `Rana Sales Contacts Customer`

## 5. Version 1 Scope
* **Implementation Note:** V1 goal is to capture and organize sales opportunities—not to automate the sales process.
* **Customer Input:** Name, Phone Number, City/District, Quantity (Optional), Message (Optional).
* **Auto-Captured Context:** `ProductID`, `ProductName`, `ProductSlug`.
* **Admin Workspace:** A simple, well-designed table/list view. 
* **Pipeline Statuses:** `NEW` → `IN_PROGRESS` → `COMPLETED` | `CANCELLED`.

## 6. Architectural Constraints (Not in V1)
* **Scope Limits:** NO Kanban boards, NO drag-and-drop, NO CRM dashboards, NO automated quoting.
* **No Authentication Lock:** The Opportunity domain must remain strictly independent of Authentication.
* **Route Independence:** The Opportunity workflow is route-independent. It does not assume it lives only at `/opportunity/new`.
* **Future Refactor (Presentation):** Eventually extract the Drawer state into a presentation controller (e.g., `OpportunityLauncher.tsx`) whose only responsibility is open/close/success/reset, completely hiding the drawer implementation from the consumer pages.

## 7. Client Validation (Next Sync)
* Ask Ravi: *"When a customer contacts you about a product, what information do you wish they had already given you?"* (Adjust form fields based on this answer later if needed).

## 8. Business Assumptions (Pricing)
* **Visibility Toggle:** The current V1 assumes public display of `sellingPrice`. In consultative B2B sales, pricing is often hidden or negotiated. 
* **Future Proofing:** If Rana Sales requests "Call for Price", this will be implemented as a server-side business configuration (e.g., `product.hidePricing = true`), NOT a UI code rewrite. The Opportunity Form must gracefully handle products passed to it without a price.

## 9. Future Roadmap & Enhancements (V2+)
*   **Opportunity Details Page:** V1 relies on inline status updates from the List view. V2 will introduce a dedicated `OpportunityDetailsPage` (accessible by clicking a row) for deeper context, note-taking, and historical timelines.
*   **Operational Metrics:** The system should eventually expose pipeline health metrics to the admin workspace, establishing a mental model of business throughput. Future metrics to track:
    *   New opportunities (Uncontacted)
    *   In-progress opportunities
    *   Completed deals
    *   Average response time
*   **UI/Craftsmanship Upgrades:** Evolve the native `<select>` status dropdown into a branded segmented control or premium action menu.