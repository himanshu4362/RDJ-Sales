---
Status: Immutable
Owner: Himanshu Raj
Purpose: To define the absolute engineering laws and mantras of the RDJ Business Platform. These override any technical trend or convenience.
---

# 99_Project_Principles.md

## The Ultimate Filter
Every feature, refactor, or architecture decision must answer one question:
**"Does this reduce Ravi's work?"**
If no, it does not belong in Version 1.

## The Ownership Laws
1. **One Responsibility → One Owner:** Never distribute a single logical decision across multiple layers.
2. **Page owns Orchestration:** Pages read URLs, invoke hooks, and route traffic. Zero business logic.
3. **Hook owns State:** Hooks answer "what data do I need?" and "what happens on submit?"
4. **API owns Transport:** The data layer fetches, caches, and invalidates. Zero UI knowledge.
5. **Mapper owns Translation:** Mappers explicitly translate backend realities into frontend domains.
6. **DTO Never Leaks:** A backend Data Transfer Object must never cross the mapper boundary into the UI.

## The Boundary Laws
7. **Public vs. Admin:** Administrative operations and Public customer experiences have different goals, densities, and security profiles. They must never share presentation components unless genuine, tested overlap exists. 
8. **Server is Authoritative:** The frontend hides UI; the backend hides data. Security and data visibility (e.g., `ACTIVE` products only) are enforced exclusively by the backend.

## The Implementation Laws
9. **Never Duplicate Business Rules:** A business invariant (e.g., "Active products need images") exists in exactly one place (validation schema).
10. **No Speculative Abstraction:** Do not create generic providers, global query managers, or empty folder structures for features that do not exist yet. Build it when it is needed.
11. **No Ghost Data:** Never pretend ephemeral browser state (like a blob URL) is permanent persistence. Be honest about architectural limits during the mock phase.
12. **Version 1 First:** We are building a digital workshop, not a tech demo. Get to a complete, usable V1 before polishing the pixels.
13. **Complete the Vertical Slice Before Expanding Horizontally:** Once a bounded context enters implementation, complete it to an agreed Version 1 definition and freeze it before beginning another business domain, unless a documented dependency requires otherwise. Define what "Version 1 complete" means, reach it, freeze it, move on.